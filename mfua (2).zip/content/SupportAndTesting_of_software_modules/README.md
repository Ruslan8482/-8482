### [Вернуться на Главную](/README.md)

## Поддержка и тестирование программных модулей

### Лекции

[Средства разработки технической документации](/content/SupportAndtesting_of_software_modules/Documentation.md)

[Единая система программной документации (ЕСПД)](/content/SupportAndtesting_of_software_modules/ESPD.md)

[Автоматизация документирования кода](/content/SupportAndtesting_of_software_modules/AutoDocumentation.md)

[Основы проектирования баз данных](/content/Basics_database_design/README.md)

[Проверка и отладка программного кода на C++](/content/SupportAndTesting_of_software_modules/Checking_and_debuggingCPPcode.md)

[]()

## Практические и лабораторные задания для студентов

[Самостоятельная работа: "Создание системы отчетов о тестировании программного модуля"](/content/SupportAndtesting_of_software_modules/CreatingSoftwareModuleTestingReportingSystem.md)

> Вместе со студентами показать как формируется навигация по репозиторию средствами Markdown!