print('Hello')
